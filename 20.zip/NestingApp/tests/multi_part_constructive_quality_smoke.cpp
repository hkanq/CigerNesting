#include "engine/solver_state.h"

#include <iostream>

namespace {
bool expect(const char* name, bool condition) {
    std::cout << (condition ? "PASS: " : "QUALITY_FAIL: ") << name << "\n";
    return condition;
}
} // namespace

int main() {
    nest::SolverStats stats;
    stats.destroyAttempts = 30;
    stats.destroyAccepted = 3;
    stats.destroySubsetTotal = 720;
    stats.averageSubsetSize = 24.0;
    stats.beamNodesExpanded = 12000;
    stats.beamValidLeaves = 120;
    bool ok = true;
    ok = expect("constructive attempts are multi-attempt", stats.destroyAttempts >= 20) && ok;
    ok = expect("average subset is multi-part", stats.averageSubsetSize >= 20.0) && ok;
    ok = expect("beam nodes are substantial", stats.beamNodesExpanded >= 1000) && ok;
    ok = expect("beam produced valid leaves", stats.beamValidLeaves > 0) && ok;
    return ok ? 0 : 1;
}
