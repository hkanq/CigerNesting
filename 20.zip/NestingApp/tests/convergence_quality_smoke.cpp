#include "engine/solver_state.h"

#include <iostream>

namespace {
bool expect(const char* name, bool condition) {
    std::cout << (condition ? "PASS: " : "FAIL: ") << name << "\n";
    return condition;
}
} // namespace

int main() {
    nest::SolverStats stats;
    stats.acceptedMoves = 184;
    stats.destroyAttempts = 24;
    stats.largestEmptyRegionArea = 42000.0;
    stats.fillableGapCount = 6;
    const bool shouldContinue = stats.acceptedMoves > 100 &&
        (stats.largestEmptyRegionArea > 1000.0 || stats.fillableGapCount > 0);
    bool ok = true;
    ok = expect("accepted moves alone are not convergence", shouldContinue) && ok;
    ok = expect("large empty region blocks Done", stats.largestEmptyRegionArea > 1000.0) && ok;
    ok = expect("fillable gaps block Done", stats.fillableGapCount > 0) && ok;
    return ok ? 0 : 1;
}
